import React from "react";

const Homepage = () => {
  return (
    <div>
      <h1>homepage</h1>
    </div>
  );
};

export default Homepage;
